# QLab Disk Performance Tester

Professional video storage testing tool for macOS with bundled fio binaries.

## Features
- Disk performance testing optimized for QLab workflows
- Bundled fio binaries for Apple Silicon and Intel Macs
- Easy installation with install.sh script
- Comprehensive performance metrics and QLab suitability analysis

## Installation
```bash
./install.sh
source ~/.zshrc
```

## Usage
```bash
python3 qlab_disk_tester.py
```

## Quick Test
```bash
./test.sh
```

## Package Structure
```
qlab-disk-tester/
├── bin/
│   ├── fio-macos-arm64     # fio for Apple Silicon
│   └── fio-macos-x86_64    # fio for Intel Macs
├── lib/                    # Core functionality modules
├── templates/              # Report templates
├── qlab_disk_tester.py     # Main application
├── requirements.txt        # Python dependencies
├── install.sh              # Setup script
├── README.md               # Documentation
└── test.sh                 # Quick test script
```

## Support
For issues, please open a GitHub ticket.