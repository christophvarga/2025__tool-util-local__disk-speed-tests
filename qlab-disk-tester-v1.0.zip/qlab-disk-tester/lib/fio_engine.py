import subprocess
import json
import os
import time

class FioEngine:
    def __init__(self, test_file_path="/tmp/fio_test_file", fio_path="fio"):
        self.test_file_path = test_file_path
        self.fio_path = fio_path

    def _get_fio_parameters(self, test_mode, disk_path, test_size_gb):
        """
        Returns fio parameters for a given test mode.
        test_size_gb will be used to determine the actual size for the test file.
        """
        # Convert GB to bytes for fio size parameter
        test_size_bytes = test_size_gb * 1024 * 1024 * 1024

        # macOS-optimized parameters for realistic performance
        # Use --direct=1 for accurate disk testing (bypasses OS cache)
        base_params = [
            self.fio_path,
            '--output-format=json',
            '--direct=1', # Essential for accurate disk performance testing
            f'--filename={disk_path}/{os.path.basename(self.test_file_path)}',
            f'--size={test_size_bytes}',
            '--ioengine=sync', # Most reliable on macOS
            '--randrepeat=0', # Ensure non-repeating random patterns
            '--norandommap', # Ensure non-repeating random patterns
            '--group_reporting', # Report aggregate statistics for all jobs
            '--output=-'  # Output JSON to stdout instead of file
        ]

        if test_mode == "setup_check":
            # Setup Check (30s) - Quick test to verify basic functionality
            return [
                base_params + [
                    '--name=setup_read',
                    '--rw=read',
                    '--bs=1M',
                    '--numjobs=1',
                    '--runtime=30',
                    '--iodepth=1'
                ],
                base_params + [
                    '--name=setup_write',
                    '--rw=write',
                    '--bs=1M',
                    '--numjobs=1',
                    '--runtime=30',
                    '--iodepth=1'
                ]
            ]
        elif test_mode == "baseline_streaming":
            # Baseline Streaming Test (1h)
            return [
                base_params + [
                    '--name=baseline_streaming',
                    '--rw=read',
                    '--bs=1M',
                    '--numjobs=4',
                    '--time_based',
                    '--runtime=3600',
                    '--rate=700M',
                    '--iodepth=16',
                    '--log_avg_msec=100',
                    '--write_bw_log=baseline_bw',
                    '--write_lat_log=baseline_lat'
                ]
            ]
        elif test_mode == "qlab_pattern":
            # QLab-Pattern mit Random Seeks (2h)
            return [
                base_params + [
                    '--name=qlab_pattern',
                    '--rw=randrw',
                    '--rwmixread=95',
                    '--bs=1M',
                    '--numjobs=6',
                    '--time_based',
                    '--runtime=7200',
                    '--rate=800M,200M',
                    '--iodepth=32',
                    '--random_generator=tausworthe64',
                    '--log_avg_msec=100',
                    '--write_bw_log=qlab_pattern_bw',
                    '--write_lat_log=qlab_pattern_lat'
                ]
            ]
        elif test_mode == "crossfade_stress":
            # Stress Test - Überblendungs-Peaks (2h)
            return [
                base_params + [
                    '--name=crossfade_stress',
                    '--rw=read',
                    '--bs=2M',
                    '--numjobs=8',
                    '--time_based',
                    '--runtime=7200',
                    '--rate=2100M',
                    '--rate_process=poisson',
                    '--iodepth=64',
                    '--thinktime=5000000',
                    '--thinktime_spin=1000000',
                    '--log_avg_msec=100',
                    '--write_bw_log=crossfade_bw',
                    '--write_lat_log=crossfade_lat',
                    '--lat_percentiles=1'
                ]
            ]
        else:
            raise ValueError("Invalid test mode specified.")

    def execute_fio_test(self, test_mode, disk_path, test_size_gb):
        """
        Executes fio tests for the given mode and returns the parsed JSON output.
        """
        job_commands = self._get_fio_parameters(test_mode, disk_path, test_size_gb)
        all_results = []

        for i, cmd_parts in enumerate(job_commands):
            print(f"Running fio test: {' '.join(cmd_parts)}")
            try:
                # Pre-create test file if it's a write test, or if it's a read test and file doesn't exist
                # fio will create it, but for consistency and to ensure size, we can manage it.
                # For simplicity, fio will create/manage the file based on --size.
                
                # Execute fio command
                process = subprocess.Popen(cmd_parts, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                stdout, stderr = process.communicate()

                if process.returncode != 0:
                    print(f"fio test failed for job {cmd_parts[0]}: {stderr}")
                    continue

                # Parse JSON output
                try:
                    result_json = json.loads(stdout)
                    all_results.append(result_json)
                except json.JSONDecodeError:
                    print(f"Failed to parse fio JSON output for job {cmd_parts[0]}: {stdout}")
                    continue

            except FileNotFoundError:
                print("Error: fio command not found. Please ensure fio is installed and in your PATH.")
                return None
            except Exception as e:
                print(f"An unexpected error occurred during fio execution: {e}")
                return None
            finally:
                # Clean up test file after each job if it's a write test or if it's the last job
                # For simplicity, we'll let fio manage the file creation/deletion for now.
                # A more robust solution might involve creating a single large file once.
                pass # Cleanup will be handled externally or by fio itself

        return all_results

    def cleanup_test_files(self, disk_path):
        """Removes the fio test file from the disk."""
        file_to_remove = os.path.join(disk_path, os.path.basename(self.test_file_path))
        if os.path.exists(file_to_remove):
            try:
                os.remove(file_to_remove)
                print(f"Cleaned up test file: {file_to_remove}")
            except Exception as e:
                print(f"Error cleaning up test file {file_to_remove}: {e}")

if __name__ == "__main__":
    # Example Usage:
    engine = FioEngine()
    
    # Example: Quick Test on /tmp
    print("--- Running Quick Test on /tmp ---")
    results = engine.execute_fio_test("quick", "/tmp", 1)
    if results:
        print(json.dumps(results, indent=2))
    
    # Example: Standard QLab Test on /tmp
    print("\n--- Running Standard QLab Test on /tmp ---")
    results = engine.execute_fio_test("standard_qlab", "/tmp", 20)
    if results:
        print(json.dumps(results, indent=2))

    # Clean up after examples
    engine.cleanup_test_files("/tmp")
