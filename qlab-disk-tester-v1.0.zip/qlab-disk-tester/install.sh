#!/bin/bash
set -e

echo "🚀 Installing QLab Disk Tester..."

# Detect Architecture
ARCH=$(uname -m)
echo "Detected architecture: $ARCH"

# Select correct fio binary
if [[ "$ARCH" == "arm64" ]]; then
    FIO_BINARY="bin/fio-macos-arm64"
elif [[ "$ARCH" == "x86_64" ]]; then
    FIO_BINARY="bin/fio-macos-x86_64"
else
    echo "❌ Unsupported architecture: $ARCH"
    exit 1
fi

# Check if binary exists
if [[ ! -f "$FIO_BINARY" ]]; then
    echo "❌ fio binary not found: $FIO_BINARY"
    exit 1
fi

# Create local bin directory
mkdir -p ~/.local/bin

# Copy fio binary
cp "$FIO_BINARY" ~/.local/bin/fio-qlab
chmod +x ~/.local/bin/fio-qlab

# Add to PATH if not already there
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
    echo "✅ Added ~/.local/bin to PATH"
fi

# Install Python dependencies
if command -v python3 &> /dev/null; then
    python3 -m pip install -r requirements.txt
    echo "✅ Python dependencies installed"
else
    echo "⚠️  Python3 not found - install manually"
fi

echo "✅ Installation complete!"
echo ""
echo "Usage:"
echo "  python3 qlab_disk_tester.py"
echo ""
echo "Note: Restart your terminal or run:"
echo "  source ~/.zshrc"