#!/bin/bash
echo "🧪 Quick fio test..."

# Check if fio-qlab exists
if command -v fio-qlab &> /dev/null; then
    echo "✅ fio-qlab found"
    fio-qlab --version
    
    # Quick test
    echo "Running 10-second test..."
    fio-qlab --name=quicktest --directory=/tmp --rw=read --bs=1M --size=1G --runtime=10
else
    echo "❌ fio-qlab not found. Run install.sh first."
fi