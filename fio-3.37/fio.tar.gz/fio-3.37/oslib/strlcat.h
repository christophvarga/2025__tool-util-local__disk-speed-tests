#ifndef CONFIG_STRLCAT

#ifndef FIO_STRLCAT_H
#define FIO_STRLCAT_H

#include <stddef.h>

size_t strlcat(char *dst, const char *src, size_t dsize);

#endif

#endif
